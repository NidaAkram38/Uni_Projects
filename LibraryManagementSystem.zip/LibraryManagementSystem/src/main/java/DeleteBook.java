import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DeleteBook extends JFrame {
    private JTextField idField;
    private JButton deleteButton, clearButton;

    public DeleteBook() {
        setTitle("Delete Book");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Fullscreen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Main panel with GridBagLayout
        JPanel mainPanel = new JPanel(new GridBagLayout());
        setContentPane(mainPanel);

        Font labelFont = new Font("Segoe UI", Font.BOLD, 20);
        Font fieldFont = new Font("Segoe UI", Font.BOLD, 18);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 20, 15, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Label for Book ID
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        JLabel lblId = new JLabel("Book ID:");
        lblId.setFont(labelFont);
        mainPanel.add(lblId, gbc);

        // Input field for Book ID
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        idField = new JTextField();
        idField.setFont(fieldFont);
        idField.setPreferredSize(new Dimension(250, 36));
        mainPanel.add(idField, gbc);

        // Delete Button
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        deleteButton = new JButton("Delete");
        deleteButton.setFont(labelFont);
        deleteButton.setPreferredSize(new Dimension(150, 40));
        mainPanel.add(deleteButton, gbc);

        // Clear Button
        gbc.gridx = 1;
        clearButton = new JButton("Clear");
        clearButton.setFont(labelFont);
        clearButton.setPreferredSize(new Dimension(150, 40));
        mainPanel.add(clearButton, gbc);

        // Button actions
        deleteButton.addActionListener(e -> deleteBook());
        clearButton.addActionListener(e -> clearFields());

        setVisible(true);
    }

    private void deleteBook() {
        String idText = idField.getText().trim();
        if (idText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Book ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int bookId;
        try {
            bookId = Integer.parseInt(idText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Book ID must be a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "This book might be used in borrowings.\nDeleting it will also delete related borrowing records.\nDo you want to proceed?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try (Connection conn = DBConnect.getConnection()) {
            conn.setAutoCommit(false); // Start transaction

            // Step 1: Delete related borrowings first
            String deleteBorrowingsSQL = "DELETE FROM borrowings WHERE book_id = ?";
            try (PreparedStatement pstmt1 = conn.prepareStatement(deleteBorrowingsSQL)) {
                pstmt1.setInt(1, bookId);
                pstmt1.executeUpdate();
            }

            // Step 2: Delete the book
            String deleteBookSQL = "DELETE FROM books WHERE book_id = ?";
            try (PreparedStatement pstmt2 = conn.prepareStatement(deleteBookSQL)) {
                pstmt2.setInt(1, bookId);
                int rowsDeleted = pstmt2.executeUpdate();

                if (rowsDeleted > 0) {
                    conn.commit(); // Commit the transaction
                    JOptionPane.showMessageDialog(this, "Book and related records deleted successfully!");
                    clearFields();
                } else {
                    conn.rollback(); // Rollback if book not found
                    JOptionPane.showMessageDialog(this, "No book found with ID: " + bookId, "Not Found", JOptionPane.INFORMATION_MESSAGE);
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        idField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DeleteBook::new);
    }
}
