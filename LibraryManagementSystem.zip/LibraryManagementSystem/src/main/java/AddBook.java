import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddBook extends JFrame {
    private JTextField titleField, authorField, genreField, yearField;
    private JCheckBox availableCheckBox;
    private JButton addButton, clearButton;

    public AddBook() {
        setTitle("Add New Book");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Fullscreen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Font labelFont = new Font("Segoe UI", Font.BOLD, 18);
        Font fieldFont = new Font("Segoe UI", Font.BOLD, 16);

        // Background panel
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon("src/main/resources/library.jpg"); // Adjust path if needed
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        };

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(230, 230, 230)); // Light gray
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        // Utility method to create a label-field pair panel
        mainPanel.add(createInputRow("Title:", titleField = new JTextField(), labelFont, fieldFont));
        mainPanel.add(createInputRow("Author:", authorField = new JTextField(), labelFont, fieldFont));
        mainPanel.add(createInputRow("Genre:", genreField = new JTextField(), labelFont, fieldFont));
        mainPanel.add(createInputRow("Published Year:", yearField = new JTextField(), labelFont, fieldFont));

        // Availability
        JPanel availPanel = new JPanel();
        availPanel.setBackground(mainPanel.getBackground());
        availPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel lblAvailable = new JLabel("Available:");
        lblAvailable.setFont(labelFont);
        lblAvailable.setForeground(Color.BLACK);
        availableCheckBox = new JCheckBox();
        availableCheckBox.setBackground(mainPanel.getBackground());
        availPanel.add(lblAvailable);
        availPanel.add(availableCheckBox);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        mainPanel.add(availPanel);

        // Buttons
        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(mainPanel.getBackground());
        addButton = new JButton("Add Book");
        clearButton = new JButton("Clear");
        addButton.setFont(labelFont);
        clearButton.setFont(labelFont);
        btnPanel.add(addButton);
        btnPanel.add(Box.createHorizontalStrut(50));
        btnPanel.add(clearButton);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        mainPanel.add(btnPanel);

        addButton.addActionListener(e -> addBook());
        clearButton.addActionListener(e -> clearFields());

        add(mainPanel);
        setVisible(true);
    }

    private JPanel createInputRow(String labelText, JTextField field, Font labelFont, Font fieldFont) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER,5,5));
        panel.setBackground(new Color(230, 230, 230));
        JLabel label = new JLabel(labelText);
        label.setFont(labelFont);
        label.setForeground(Color.BLACK);
        field.setFont(fieldFont);
        field.setPreferredSize(new Dimension(280, 30));
        panel.add(label);
        panel.add(field);
        panel.setAlignmentX(Component.CENTER_ALIGNMENT);
        return panel;
    }

    private void addBook() {
        String title = titleField.getText().trim();
        String author = authorField.getText().trim();
        String genre = genreField.getText().trim();
        String yearText = yearField.getText().trim();
        boolean available = availableCheckBox.isSelected();

        if (title.isEmpty() || author.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Title and Author are required fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int publishedYear = 0;
        if (!yearText.isEmpty()) {
            try {
                publishedYear = Integer.parseInt(yearText);
                if (publishedYear < 1000 || publishedYear > 9999) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid year (e.g., 2023).", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Published Year must be a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        String sql = "INSERT INTO books (title, author, genre, published_year, available) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, title);
            pstmt.setString(2, author);
            pstmt.setString(3, genre.isEmpty() ? null : genre);
            if (publishedYear == 0) {
                pstmt.setNull(4, java.sql.Types.INTEGER);
            } else {
                pstmt.setInt(4, publishedYear);
            }
            pstmt.setBoolean(5, available);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Book added successfully!");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add book.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        titleField.setText("");
        authorField.setText("");
        genreField.setText("");
        yearField.setText("");
        availableCheckBox.setSelected(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AddBook::new);
    }
}
