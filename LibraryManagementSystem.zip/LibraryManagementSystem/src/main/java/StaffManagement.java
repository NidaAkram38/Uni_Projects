import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class StaffManagement extends JFrame {
    private JTextField nameField, emailField, phoneField, positionField, departmentField;
    private JButton saveButton;

    public StaffManagement() {
        setTitle("Staff Management");

        // Full-screen window
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Font labelFont = new Font("Segoe UI", Font.BOLD, 18);
        Font fieldFont = new Font("Segoe UI", Font.BOLD, 16);

        // Labels and fields
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(labelFont);
        nameField = createTextField("Enter Name", fieldFont);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(labelFont);
        emailField = createTextField("Enter Email", fieldFont);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setFont(labelFont);
        phoneField = createTextField("Enter Phone Number", fieldFont);

        JLabel positionLabel = new JLabel("Position:");
        positionLabel.setFont(labelFont);
        positionField = createTextField("Enter Position", fieldFont);

        JLabel departmentLabel = new JLabel("Department:");
        departmentLabel.setFont(labelFont);
        departmentField = createTextField("Enter Department", fieldFont);

        // Save button
        saveButton = new JButton("Save");
        saveButton.setFont(labelFont);
        saveButton.setPreferredSize(new Dimension(120, 36));
        saveButton.addActionListener(e -> saveStaff());

        // Form layout panel
        JPanel formPanel = new JPanel();
        formPanel.setBackground(Color.WHITE); // No background image
        GroupLayout layout = new GroupLayout(formPanel);
        formPanel.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(
                layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                                .addComponent(nameLabel)
                                .addComponent(emailLabel)
                                .addComponent(phoneLabel)
                                .addComponent(positionLabel)
                                .addComponent(departmentLabel))
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addComponent(nameField)
                                .addComponent(emailField)
                                .addComponent(phoneField)
                                .addComponent(positionField)
                                .addComponent(departmentField)
                                .addComponent(saveButton, GroupLayout.Alignment.CENTER))
        );

        layout.setVerticalGroup(
                layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(nameLabel)
                                .addComponent(nameField))
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(emailLabel)
                                .addComponent(emailField))
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(phoneLabel)
                                .addComponent(phoneField))
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(positionLabel)
                                .addComponent(positionField))
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(departmentLabel)
                                .addComponent(departmentField))
                        .addComponent(saveButton)
        );

        // Center form using wrapper panel and GridBagLayout
        JPanel wrapperPanel = new JPanel(new GridBagLayout());
        wrapperPanel.setBackground(Color.WHITE);
        wrapperPanel.add(formPanel);

        setContentPane(wrapperPanel);
        setVisible(true);
    }

    private JTextField createTextField(String placeholder, Font font) {
        JTextField field = new JTextField(20);
        field.setFont(font);
        field.setForeground(Color.GRAY);
        field.setText(placeholder);
        field.setPreferredSize(new Dimension(400, 40));

        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (field.getText().isEmpty()) {
                    field.setText(placeholder);
                    field.setForeground(Color.GRAY);
                }
            }
        });

        return field;
    }

    private void saveStaff() {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String position = positionField.getText().trim();
        String department = departmentField.getText().trim();

        if (name.equals("Enter Name") || name.isEmpty() || email.equals("Enter Email") || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name and Email are required.");
            return;
        }

        if (!email.contains("@") || !email.contains(".")) {
            JOptionPane.showMessageDialog(this, "Please enter a valid email address.");
            return;
        }

        if (phone.length() > 0 && !phone.matches("[0-9]+")) {
            JOptionPane.showMessageDialog(this, "Phone number can only contain digits.");
            return;
        }

        String sql = "INSERT INTO staff (name, email, phone, position, department) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DBConnect.getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {

            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phone.equals("Enter Phone Number") ? "" : phone);
            pstmt.setString(4, position.equals("Enter Position") ? "" : position);
            pstmt.setString(5, department.equals("Enter Department") ? "" : department);

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Staff added successfully!");
            this.dispose();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StaffManagement());
    }
}
