import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LoginForm extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;
    private boolean passwordVisible = false;
    private JButton eyeBtn;

    public LoginForm() {
        setTitle("Login");
        setExtendedState(JFrame.MAXIMIZED_BOTH);  // Fullscreen
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Main Panel
        JPanel mainPanel = new JPanel(new GridBagLayout());
        add(mainPanel);

        Font font = new Font("Segoe UI", Font.BOLD, 18);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Email Label
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(font);
        mainPanel.add(emailLabel, gbc);

        // Email Field
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        emailField = new JTextField();
        emailField.setPreferredSize(new Dimension(380, 40));
        emailField.setFont(font);
        mainPanel.add(emailField, gbc);

        // Password Label
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(font);
        mainPanel.add(passLabel, gbc);

        // Password Field + Eye Button
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        JPanel passwordPanel = new JPanel(new BorderLayout());
        passwordPanel.setPreferredSize(new Dimension(380, 40));

        passwordField = new JPasswordField();
        passwordField.setFont(font);
        passwordField.setEchoChar('•');
        passwordPanel.add(passwordField, BorderLayout.CENTER);

        eyeBtn = new JButton("👁");
        eyeBtn.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        eyeBtn.setFocusable(false);
        eyeBtn.setPreferredSize(new Dimension(45, 40));
        passwordPanel.add(eyeBtn, BorderLayout.EAST);
        mainPanel.add(passwordPanel, gbc);

        eyeBtn.addActionListener(e -> {
            passwordVisible = !passwordVisible;
            passwordField.setEchoChar(passwordVisible ? (char) 0 : '•');
            eyeBtn.setText(passwordVisible ? "🙈" : "👁");
        });

        // Signup Button
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_END;
        JButton signupBtn = new JButton("Signup");
        signupBtn.setPreferredSize(new Dimension(130, 36));
        signupBtn.setFont(font);
        mainPanel.add(signupBtn, gbc);

        // Login Button
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        JButton loginBtn = new JButton("Login");
        loginBtn.setPreferredSize(new Dimension(130, 36));
        loginBtn.setFont(font);
        mainPanel.add(loginBtn, gbc);

        // Signup Action
        signupBtn.addActionListener(e -> {
            dispose();
            new SignupForm().setVisible(true);
        });

        // Login Action
        loginBtn.addActionListener(e -> {
            String email = emailField.getText().trim();
            String password = new String(passwordField.getPassword());
            if (email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Both fields are required.");
                return;
            }
            try (Connection conn = DBConnect.getConnection()) {
                PreparedStatement pst = conn.prepareStatement(
                        "SELECT * FROM users WHERE email=? AND password=?"
                );
                pst.setString(1, email);
                pst.setString(2, password);
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    dispose();
                    new LibraryDashboard().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid credentials.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "DB error: " + ex.getMessage());
            }
        });
    }
}
