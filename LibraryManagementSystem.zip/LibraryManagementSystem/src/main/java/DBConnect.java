import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DBConnect class manages the connection to the MySQL database.
 */
public class DBConnect {
    private static final String URL = "jdbc:mysql://localhost:3306/library_db";
    private static final String USER = "root"; // Change if your MySQL user is different
    private static final String PASSWORD = ""; // Change to your MySQL password

    /**
     * Get a connection to the database.
     * @return Connection object or null if connection fails.
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}



