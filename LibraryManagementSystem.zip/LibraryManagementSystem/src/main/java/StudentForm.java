import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StudentForm extends JFrame {
    private JTextField nameField, emailField, phoneField, courseField, departmentField;
    private JButton saveButton;
    private JLabel messageLabel;

    public StudentForm() {
        setTitle("Student Management");
        setExtendedState(JFrame.MAXIMIZED_BOTH);  // Full screen
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Font labelFont = new Font("Segoe UI", Font.BOLD, 18);
        Font fieldFont = new Font("Segoe UI", Font.BOLD, 16);

        // Labels with black text color
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(labelFont);
        nameLabel.setForeground(Color.BLACK);

        nameField = createTextField("Enter Name", fieldFont);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(labelFont);
        emailLabel.setForeground(Color.BLACK);

        emailField = createTextField("Enter Email", fieldFont);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setFont(labelFont);
        phoneLabel.setForeground(Color.BLACK);

        phoneField = createTextField("Enter Phone Number", fieldFont);

        JLabel courseLabel = new JLabel("Course:");
        courseLabel.setFont(labelFont);
        courseLabel.setForeground(Color.BLACK);

        courseField = createTextField("Enter Course", fieldFont);

        JLabel departmentLabel = new JLabel("Department:");
        departmentLabel.setFont(labelFont);
        departmentLabel.setForeground(Color.BLACK);

        departmentField = createTextField("Enter Department", fieldFont);

        saveButton = new JButton("Save");
        saveButton.setFont(labelFont);
        saveButton.setPreferredSize(new Dimension(120, 36));
        saveButton.addActionListener(e -> saveStudent());

        messageLabel = new JLabel("");
        messageLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        messageLabel.setForeground(Color.BLUE);

        // Panel without background image
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components

        // Layout - Centering the components
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(nameLabel, gbc);

        gbc.gridx = 1;
        panel.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(emailLabel, gbc);

        gbc.gridx = 1;
        panel.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(phoneLabel, gbc);

        gbc.gridx = 1;
        panel.add(phoneField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(courseLabel, gbc);

        gbc.gridx = 1;
        panel.add(courseField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(departmentLabel, gbc);

        gbc.gridx = 1;
        panel.add(departmentField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(saveButton, gbc);

        gbc.gridy = 6;
        panel.add(messageLabel, gbc);

        add(panel);
        setVisible(true);
    }

    private JTextField createTextField(String placeholder, Font font) {
        JTextField field = new JTextField(20);
        field.setFont(font);
        field.setForeground(Color.GRAY);
        field.setText(placeholder);
        field.setPreferredSize(new Dimension(400, 40));

        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (field.getText().isEmpty()) {
                    field.setText(placeholder);
                    field.setForeground(Color.GRAY);
                }
            }
        });

        return field;
    }

    private void saveStudent() {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String course = courseField.getText().trim();
        String department = departmentField.getText().trim();

        if (name.isEmpty() || name.equals("Enter Name") || email.isEmpty() || !isValidEmail(email)) {
            messageLabel.setText("Please enter a valid name and email.");
            return;
        }

        if (!phone.matches("\\d{10,15}")) {
            messageLabel.setText("Please enter a valid phone number (10-15 digits).");
            return;
        }

        String query = "INSERT INTO students (name, email, phone, course, department, registration_date) VALUES (?, ?, ?, ?, ?, CURDATE())";
        try (Connection con = DBConnect.getConnection();
             PreparedStatement pstmt = con.prepareStatement(query)) {

            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phone);
            pstmt.setString(4, course);
            pstmt.setString(5, department);
            pstmt.executeUpdate();

            messageLabel.setText("Student added successfully!");
        } catch (SQLException e) {
            messageLabel.setText("Error: " + e.getMessage());
        }
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public static void main(String[] args) {
        new StudentForm();
    }
}
