import javax.swing.*;
import java.awt.*;

public class BooksManagement extends JFrame {
    public BooksManagement() {
        setTitle("Books Management");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Full window
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Plain JPanel instead of BackgroundPanel
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(Color.WHITE); // Optional: change color if needed
        setContentPane(mainPanel);

        Font font = new Font("Segoe UI", Font.PLAIN, 16);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 20, 15, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        JButton addBookBtn    = createButton("Add New Book", font);
        JButton viewBooksBtn  = createButton("View All Books", font);
        JButton updateBookBtn = createButton("Update Book", font);
        JButton deleteBookBtn = createButton("Delete Book", font);

        gbc.gridy = 0;
        mainPanel.add(addBookBtn, gbc);
        gbc.gridy = 1;
        mainPanel.add(viewBooksBtn, gbc);
        gbc.gridy = 2;
        mainPanel.add(updateBookBtn, gbc);
        gbc.gridy = 3;
        mainPanel.add(deleteBookBtn, gbc);

        // Actions
        addBookBtn.addActionListener(e    -> new AddBook().setVisible(true));
        viewBooksBtn.addActionListener(e  -> new ViewBooks().setVisible(true));
        updateBookBtn.addActionListener(e -> new UpdateBook().setVisible(true));
        deleteBookBtn.addActionListener(e -> new DeleteBook().setVisible(true));
    }

    private JButton createButton(String text, Font font) {
        JButton btn = new JButton(text);
        btn.setFont(font);
        btn.setPreferredSize(new Dimension(320, 45));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BooksManagement().setVisible(true));
    }
}
