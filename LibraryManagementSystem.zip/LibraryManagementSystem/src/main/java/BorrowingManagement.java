import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class BorrowingManagement extends JFrame {
    private JTextField txtStudentId, txtBookId, txtBorrowDate, txtReturnDate, txtFineAmount;
    private JComboBox<String> cmbBorrowStatus, cmbFineStatus;
    private JButton btnSave;
    private JLabel messageLabel;

    public BorrowingManagement() {
        setTitle("Borrowing Management");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Full screen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Font labelFont = new Font("Segoe UI", Font.BOLD, 18);
        Font fieldFont = new Font("Segoe UI", Font.BOLD, 16);

        // Create labels and set color
        JLabel lblStudentId   = createLabel("Student ID:", labelFont);
        txtStudentId          = createTextField(fieldFont);
        JLabel lblBookId      = createLabel("Book ID:", labelFont);
        txtBookId             = createTextField(fieldFont);
        JLabel lblBorrowDate  = createLabel("Borrow Date (YYYY-MM-DD):", labelFont);
        txtBorrowDate         = createTextField(fieldFont);
        JLabel lblReturnDate  = createLabel("Return Date (YYYY-MM-DD):", labelFont);
        txtReturnDate         = createTextField(fieldFont);
        JLabel lblStatus      = createLabel("Status:", labelFont);
        cmbBorrowStatus       = new JComboBox<>(new String[]{"Borrowed", "Returned"});
        cmbBorrowStatus.setFont(fieldFont);
        JLabel lblFineAmount  = createLabel("Fine Amount:", labelFont);
        txtFineAmount         = createTextField(fieldFont);
        txtFineAmount.setText("0");
        JLabel lblFineStatus  = createLabel("Fine Status:", labelFont);
        cmbFineStatus         = new JComboBox<>(new String[]{"Paid", "Unpaid"});
        cmbFineStatus.setFont(fieldFont);

        // Button and message label
        btnSave = new JButton("Save");
        btnSave.setFont(labelFont);
        btnSave.setPreferredSize(new Dimension(200, 40));
        btnSave.addActionListener(this::saveBorrowing);

        messageLabel = new JLabel(" ");
        messageLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        messageLabel.setForeground(Color.BLACK);

        // Apply uniform size to fields and combo
        Dimension fieldDim = new Dimension(300, 36);
        for (JComponent c : new JComponent[]{txtStudentId, txtBookId, txtBorrowDate, txtReturnDate, txtFineAmount, cmbBorrowStatus, cmbFineStatus}) {
            c.setPreferredSize(fieldDim);
        }

        // Panel without background image
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        gbc.gridx = 0; gbc.gridy = 0; panel.add(lblStudentId, gbc);
        gbc.gridx = 1; panel.add(txtStudentId, gbc);
        gbc.gridx = 0; gbc.gridy++; panel.add(lblBookId, gbc);
        gbc.gridx = 1; panel.add(txtBookId, gbc);
        gbc.gridx = 0; gbc.gridy++; panel.add(lblBorrowDate, gbc);
        gbc.gridx = 1; panel.add(txtBorrowDate, gbc);
        gbc.gridx = 0; gbc.gridy++; panel.add(lblReturnDate, gbc);
        gbc.gridx = 1; panel.add(txtReturnDate, gbc);
        gbc.gridx = 0; gbc.gridy++; panel.add(lblStatus, gbc);
        gbc.gridx = 1; panel.add(cmbBorrowStatus, gbc);
        gbc.gridx = 0; gbc.gridy++; panel.add(lblFineAmount, gbc);
        gbc.gridx = 1; panel.add(txtFineAmount, gbc);
        gbc.gridx = 0; gbc.gridy++; panel.add(lblFineStatus, gbc);
        gbc.gridx = 1; panel.add(cmbFineStatus, gbc);
        gbc.gridx = 0; gbc.gridy++; gbc.gridwidth = 2; panel.add(btnSave, gbc);
        gbc.gridy++; panel.add(messageLabel, gbc);

        add(panel);
        setVisible(true);
    }

    private JLabel createLabel(String text, Font font) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(Color.BLACK);
        return label;
    }

    private JTextField createTextField(Font font) {
        JTextField field = new JTextField();
        field.setFont(font);
        field.setForeground(Color.BLACK);
        return field;
    }

    private void saveBorrowing(ActionEvent e) {
        String sid = txtStudentId.getText().trim(),
                bid = txtBookId.getText().trim(),
                bdate = txtBorrowDate.getText().trim(),
                rdate = txtReturnDate.getText().trim(),
                status = cmbBorrowStatus.getSelectedItem().toString(),
                famt = txtFineAmount.getText().trim(),
                fstat = cmbFineStatus.getSelectedItem().toString();

        if (sid.isEmpty() || bid.isEmpty() || bdate.isEmpty()) {
            messageLabel.setText("Please fill all required fields.");
            return;
        }

        String sql = "INSERT INTO borrowings (student_id, book_id, borrow_date, return_date, status, fine_amount, fine_status) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, Integer.parseInt(sid));
            pst.setInt(2, Integer.parseInt(bid));
            pst.setString(3, bdate);
            pst.setString(4, rdate);
            pst.setString(5, status);
            pst.setDouble(6, Double.parseDouble(famt));
            pst.setString(7, fstat);
            pst.executeUpdate();

            messageLabel.setText("Record saved successfully!");
        } catch (NumberFormatException ex) {
            messageLabel.setText("IDs and fine must be numeric.");
        } catch (SQLException ex) {
            messageLabel.setText("DB error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BorrowingManagement::new);
    }
}
