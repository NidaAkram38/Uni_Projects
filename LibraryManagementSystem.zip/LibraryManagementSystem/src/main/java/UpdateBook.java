import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UpdateBook extends JFrame {
    private JTextField idField, titleField, authorField, genreField, yearField;
    private JCheckBox availableCheckBox;
    private JButton fetchButton, updateButton, clearButton;

    public UpdateBook() {
        setTitle("Update Book Information");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 12, 8, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        Font labelFont = new Font("Segoe UI", Font.BOLD, 18);
        Font fieldFont = new Font("Segoe UI", Font.BOLD, 16);

        // Row 1 - Book ID
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("Book ID:"), gbc);
        idField = new JTextField();
        idField.setFont(fieldFont);
        idField.setPreferredSize(new Dimension(300, 36));
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.LINE_START;
        add(idField, gbc);

        // Row 2 - Fetch Button
        fetchButton = new JButton("Fetch Details");
        fetchButton.setFont(labelFont);
        fetchButton.setPreferredSize(new Dimension(160, 36));
        gbc.gridx = 1; gbc.gridy = 1; gbc.gridwidth = 2;
        add(fetchButton, gbc);
        gbc.gridwidth = 1;

        // Row 3 - Title
        gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("Title:"), gbc);
        titleField = new JTextField();
        titleField.setFont(fieldFont);
        titleField.setPreferredSize(new Dimension(300, 36));
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.LINE_START;
        add(titleField, gbc);

        // Row 4 - Author
        gbc.gridx = 0; gbc.gridy = 3; gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("Author:"), gbc);
        authorField = new JTextField();
        authorField.setFont(fieldFont);
        authorField.setPreferredSize(new Dimension(300, 36));
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.LINE_START;
        add(authorField, gbc);

        // Row 5 - Genre
        gbc.gridx = 0; gbc.gridy = 4; gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("Genre:"), gbc);
        genreField = new JTextField();
        genreField.setFont(fieldFont);
        genreField.setPreferredSize(new Dimension(300, 36));
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.LINE_START;
        add(genreField, gbc);

        // Row 6 - Published Year
        gbc.gridx = 0; gbc.gridy = 5; gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("Published Year:"), gbc);
        yearField = new JTextField();
        yearField.setFont(fieldFont);
        yearField.setPreferredSize(new Dimension(300, 36));
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.LINE_START;
        add(yearField, gbc);

        // Row 7 - Available
        gbc.gridx = 0; gbc.gridy = 6; gbc.anchor = GridBagConstraints.LINE_END;
        add(new JLabel("Available:"), gbc);
        availableCheckBox = new JCheckBox();
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.LINE_START;
        add(availableCheckBox, gbc);

        // Row 8 - Update & Clear
        updateButton = new JButton("Update Book");
        updateButton.setFont(labelFont);
        updateButton.setPreferredSize(new Dimension(160, 36));
        clearButton = new JButton("Clear");
        clearButton.setFont(labelFont);
        clearButton.setPreferredSize(new Dimension(160, 36));

        gbc.gridx = 0; gbc.gridy = 7; gbc.anchor = GridBagConstraints.LINE_END;
        add(updateButton, gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.LINE_START;
        add(clearButton, gbc);

        setFieldsEnabled(false);

        fetchButton.addActionListener(e -> fetchBookDetails());
        updateButton.addActionListener(e -> updateBook());
        clearButton.addActionListener(e -> clearFields());
    }

    private void setFieldsEnabled(boolean enabled) {
        titleField.setEnabled(enabled);
        authorField.setEnabled(enabled);
        genreField.setEnabled(enabled);
        yearField.setEnabled(enabled);
        availableCheckBox.setEnabled(enabled);
        updateButton.setEnabled(enabled);
    }

    private void fetchBookDetails() {
        String idText = idField.getText().trim();
        if (idText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Book ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int bookId;
        try {
            bookId = Integer.parseInt(idText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Book ID must be a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "SELECT * FROM books WHERE book_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, bookId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                titleField.setText(rs.getString("title"));
                authorField.setText(rs.getString("author"));
                genreField.setText(rs.getString("genre"));
                int yr = rs.getInt("published_year");
                yearField.setText(yr == 0 ? "" : String.valueOf(yr));
                availableCheckBox.setSelected(rs.getBoolean("available"));
                setFieldsEnabled(true);
            } else {
                JOptionPane.showMessageDialog(this, "No book with ID " + bookId, "Not Found", JOptionPane.INFORMATION_MESSAGE);
                clearFields();
                setFieldsEnabled(false);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "DB error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateBook() {
        String idText = idField.getText().trim(),
                title = titleField.getText().trim(),
                author = authorField.getText().trim(),
                genre = genreField.getText().trim(),
                yearText = yearField.getText().trim();
        boolean avail = availableCheckBox.isSelected();

        if (title.isEmpty() || author.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Title and Author required.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int bookId;
        try {
            bookId = Integer.parseInt(idText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Book ID must be a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int yr = 0;
        if (!yearText.isEmpty()) {
            try {
                yr = Integer.parseInt(yearText);
                if (yr < 1000 || yr > 9999)
                    throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid year.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        String sql = "UPDATE books SET title=?, author=?, genre=?, published_year=?, available=? WHERE book_id=?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, title);
            pst.setString(2, author);
            pst.setString(3, genre.isEmpty() ? null : genre);
            if (yr == 0) pst.setNull(4, Types.INTEGER);
            else pst.setInt(4, yr);
            pst.setBoolean(5, avail);
            pst.setInt(6, bookId);

            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(this, "Updated successfully!");
                clearFields();
                setFieldsEnabled(false);
            } else {
                JOptionPane.showMessageDialog(this, "Update failed.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "DB error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        idField.setText("");
        titleField.setText("");
        authorField.setText("");
        genreField.setText("");
        yearField.setText("");
        availableCheckBox.setSelected(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new UpdateBook().setVisible(true));
    }
}
