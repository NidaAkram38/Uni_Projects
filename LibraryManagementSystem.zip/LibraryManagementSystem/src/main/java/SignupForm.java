import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class SignupForm extends JFrame {
    private boolean passwordVisible = false;

    public SignupForm() {
        setTitle("Signup");
        setExtendedState(JFrame.MAXIMIZED_BOTH);  // Fullscreen
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Main panel without background image
        JPanel mainPanel = new JPanel(new GridBagLayout());
        add(mainPanel);

        Font font = new Font("Segoe UI", Font.BOLD, 18);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Name Label
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(font);
        mainPanel.add(nameLabel, gbc);

        // Name Field
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        JTextField nameField = new JTextField();
        nameField.setPreferredSize(new Dimension(380, 40));
        nameField.setFont(font);
        mainPanel.add(nameField, gbc);

        // Email Label
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(font);
        mainPanel.add(emailLabel, gbc);

        // Email Field
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        JTextField emailField = new JTextField();
        emailField.setPreferredSize(new Dimension(380, 40));
        emailField.setFont(font);
        mainPanel.add(emailField, gbc);

        // Password Label
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_END;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(font);
        mainPanel.add(passwordLabel, gbc);

        // Password Field + Eye Button
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        JPanel passwordPanel = new JPanel(new BorderLayout());
        passwordPanel.setPreferredSize(new Dimension(380, 40));
        JPasswordField passwordField = new JPasswordField();
        passwordField.setFont(font);
        JButton eyeBtn1 = new JButton("👁");
        eyeBtn1.setPreferredSize(new Dimension(45, 40));
        eyeBtn1.setFocusable(false);
        passwordPanel.add(passwordField, BorderLayout.CENTER);
        passwordPanel.add(eyeBtn1, BorderLayout.EAST);
        mainPanel.add(passwordPanel, gbc);

        // Confirm Label
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_END;
        JLabel confirmLabel = new JLabel("Confirm:");
        confirmLabel.setFont(font);
        mainPanel.add(confirmLabel, gbc);

        // Confirm Field + Eye Button
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        JPanel confirmPanel = new JPanel(new BorderLayout());
        confirmPanel.setPreferredSize(new Dimension(380, 40));
        JPasswordField confirmField = new JPasswordField();
        confirmField.setFont(font);
        JButton eyeBtn2 = new JButton("👁");
        eyeBtn2.setPreferredSize(new Dimension(45, 40));
        eyeBtn2.setFocusable(false);
        confirmPanel.add(confirmField, BorderLayout.CENTER);
        confirmPanel.add(eyeBtn2, BorderLayout.EAST);
        mainPanel.add(confirmPanel, gbc);

        // Toggle Eye Buttons
        eyeBtn1.addActionListener(e -> {
            passwordVisible = !passwordVisible;
            passwordField.setEchoChar(passwordVisible ? (char) 0 : '•');
            eyeBtn1.setText(passwordVisible ? "🙈" : "👁");
        });

        eyeBtn2.addActionListener(e -> {
            passwordVisible = !passwordVisible;
            confirmField.setEchoChar(passwordVisible ? (char) 0 : '•');
            eyeBtn2.setText(passwordVisible ? "🙈" : "👁");
        });

        // Login Button (was Register)
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton loginBtn = new JButton("Signup");
        loginBtn.setPreferredSize(new Dimension(200, 40));
        loginBtn.setFont(font);
        mainPanel.add(loginBtn, gbc);

        // Signup Logic
        loginBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String pass = new String(passwordField.getPassword());
            String conf = new String(confirmField.getPassword());

            if (name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields required.");
                return;
            }

            if (!pass.equals(conf)) {
                JOptionPane.showMessageDialog(this, "Passwords do not match.");
                return;
            }

            try (Connection conn = DBConnect.getConnection()) {
                PreparedStatement pst = conn.prepareStatement(
                        "INSERT INTO users (name, email, password) VALUES (?, ?, ?)"
                );
                pst.setString(1, name);
                pst.setString(2, email);
                pst.setString(3, pass);
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Signup successful!");
                dispose();
                new LoginForm().setVisible(true);
            } catch (SQLException ex) {
                if (ex.getMessage().contains("Duplicate")) {
                    JOptionPane.showMessageDialog(this, "Email already registered.");
                } else {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "DB error: " + ex.getMessage());
                }
            }
        });
    }
}
