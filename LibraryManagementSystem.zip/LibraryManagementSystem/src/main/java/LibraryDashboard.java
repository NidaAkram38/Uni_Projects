import javax.swing.*;
import java.awt.*;

public class LibraryDashboard extends JFrame {
    public LibraryDashboard() {
        setTitle("Library Management System");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Full-screen window
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Plain white panel instead of background image
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(Color.WHITE); // Optional: set a different color
        setContentPane(mainPanel);

        Font font = new Font("Segoe UI", Font.BOLD, 18);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 10, 15, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        JButton booksBtn = createButton("Books Management", font);
        JButton staffBtn = createButton("Staff Management", font);
        JButton studentsBtn = createButton("Students Management", font);
        JButton borrowingBtn = createButton("Borrowing Management", font);

        gbc.gridy = 0;
        mainPanel.add(booksBtn, gbc);
        gbc.gridy = 1;
        mainPanel.add(staffBtn, gbc);
        gbc.gridy = 2;
        mainPanel.add(studentsBtn, gbc);
        gbc.gridy = 3;
        mainPanel.add(borrowingBtn, gbc);

        booksBtn.addActionListener(e -> new BooksManagement().setVisible(true));
        staffBtn.addActionListener(e -> new StaffManagement().setVisible(true));
        studentsBtn.addActionListener(e -> new StudentForm().setVisible(true));
        borrowingBtn.addActionListener(e -> new BorrowingManagement().setVisible(true));
    }

    private JButton createButton(String text, Font font) {
        JButton btn = new JButton(text);
        btn.setPreferredSize(new Dimension(280, 40));
        btn.setFont(font);
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LibraryDashboard().setVisible(true));
    }
}
