import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewBooks extends JFrame {
    private JTable booksTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JButton searchButton, refreshButton;
    private JLabel lblSearch;

    public ViewBooks() {
        setTitle("View All Books");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Fullscreen
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        Font labelFont = new Font("Segoe UI", Font.BOLD, 18);
        Font fieldFont = new Font("Segoe UI", Font.BOLD, 16);

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        setContentPane(mainPanel);

        // Top panel with search
        JPanel topPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Search label
        lblSearch = new JLabel("Search by Title:");
        lblSearch.setFont(labelFont);
        gbc.gridx = 0;
        gbc.gridy = 0;
        topPanel.add(lblSearch, gbc);

        // Search field
        searchField = new JTextField();
        searchField.setFont(fieldFont);
        searchField.setPreferredSize(new Dimension(300, 36));
        gbc.gridx = 1;
        topPanel.add(searchField, gbc);

        // Search button
        searchButton = new JButton("Search");
        searchButton.setFont(labelFont);
        gbc.gridx = 2;
        topPanel.add(searchButton, gbc);

        // Refresh button
        refreshButton = new JButton("Refresh");
        refreshButton.setFont(labelFont);
        gbc.gridx = 3;
        topPanel.add(refreshButton, gbc);

        mainPanel.add(topPanel, BorderLayout.NORTH);

        // Table setup
        booksTable = new JTable();
        booksTable.setFont(fieldFont);
        booksTable.setRowHeight(24);
        booksTable.setForeground(Color.BLACK);
        booksTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 16));
        booksTable.getTableHeader().setForeground(Color.BLACK);

        tableModel = new DefaultTableModel(
                new Object[]{"BOOK_ID", "Title", "Author", "Genre", "Published Year", "Available"}, 0
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        booksTable.setModel(tableModel);
        JScrollPane scrollPane = new JScrollPane(booksTable);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Load all books initially
        loadBooks("");

        // Button actions
        searchButton.addActionListener(e -> loadBooks(searchField.getText().trim()));
        refreshButton.addActionListener(e -> {
            searchField.setText("");
            loadBooks("");
        });

        setVisible(true);
    }

    private void loadBooks(String keyword) {
        tableModel.setRowCount(0); // Clear table

        String sql;
        boolean isSearch = !keyword.isEmpty();

        if (isSearch) {
            // Exact match (case-insensitive)
            sql = "SELECT * FROM books WHERE LOWER(title) = LOWER(?)";
        } else {
            sql = "SELECT * FROM books";
        }

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            if (isSearch) {
                pst.setString(1, keyword);
            }

            ResultSet rs = pst.executeQuery();
            boolean found = false;

            while (rs.next()) {
                found = true;
                tableModel.addRow(new Object[]{
                        rs.getInt("book_id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("genre"),
                        rs.getInt("published_year"),
                        rs.getBoolean("available") ? "Yes" : "No"
                });
            }

            if (isSearch && !found) {
                JOptionPane.showMessageDialog(this,
                        "No book found with title: " + keyword,
                        "Not Found", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Error loading books: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ViewBooks::new);
    }
}
